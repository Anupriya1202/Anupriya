int main(){
int number1=4;
2number2=5;
sum=num1+number2;
num +=2;
return 0;
}